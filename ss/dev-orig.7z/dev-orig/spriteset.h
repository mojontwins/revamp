// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
extern unsigned char sprite_17_a []; 
extern unsigned char sprite_17_b []; 
extern unsigned char sprite_17_c []; 
extern unsigned char sprite_18_a []; 
extern unsigned char sprite_18_b []; 
extern unsigned char sprite_18_c []; 
extern unsigned char sprite_19_a []; 
extern unsigned char sprite_19_b []; 
extern unsigned char sprite_19_c []; 
extern unsigned char sprite_20_a []; 
extern unsigned char sprite_20_b []; 
extern unsigned char sprite_20_c []; 
extern unsigned char sprite_21_a []; 
extern unsigned char sprite_21_b []; 
extern unsigned char sprite_21_c []; 
extern unsigned char sprite_22_a []; 
extern unsigned char sprite_22_b []; 
extern unsigned char sprite_22_c []; 
extern unsigned char sprite_23_a []; 
extern unsigned char sprite_23_b []; 
extern unsigned char sprite_23_c []; 
extern unsigned char sprite_24_a []; 
extern unsigned char sprite_24_b []; 
extern unsigned char sprite_24_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 7, 240
        defb 15, 224
        defb 15, 192
        defb 21, 128
        defb 42, 0
        defb 85, 0
        defb 42, 0
        defb 32, 128
        defb 62, 128
        defb 63, 128
        defb 31, 192
        defb 15, 224
        defb 2, 240
        defb 5, 224
        defb 10, 192
        defb 21, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 0, 127
        defb 128, 15
        defb 176, 7
        defb 88, 3
        defb 184, 3
        defb 80, 3
        defb 12, 1
        defb 220, 1
        defb 48, 3
        defb 240, 7
        defb 128, 15
        defb 192, 31
        defb 0, 15
        defb 112, 7
        defb 184, 3
        defb 80, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 14, 224
        defb 31, 192
        defb 30, 128
        defb 85, 0
        defb 170, 0
        defb 85, 0
        defb 168, 0
        defb 65, 0
        defb 124, 0
        defb 127, 0
        defb 62, 128
        defb 31, 128
        defb 2, 0
        defb 81, 0
        defb 34, 0
        defb 21, 128
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 0, 255
        defb 0, 31
        defb 224, 15
        defb 112, 7
        defb 176, 7
        defb 96, 3
        defb 28, 1
        defb 188, 1
        defb 32, 3
        defb 224, 15
        defb 0, 31
        defb 128, 3
        defb 56, 1
        defb 92, 1
        defb 168, 3
        defb 64, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 3, 248
        defb 7, 240
        defb 7, 224
        defb 21, 192
        defb 42, 128
        defb 21, 128
        defb 42, 128
        defb 16, 192
        defb 31, 192
        defb 31, 192
        defb 15, 224
        defb 7, 128
        defb 34, 0
        defb 85, 0
        defb 42, 0
        defb 5, 128
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 128, 63
        defb 192, 7
        defb 184, 3
        defb 92, 1
        defb 172, 1
        defb 88, 0
        defb 7, 0
        defb 111, 0
        defb 24, 0
        defb 248, 3
        defb 128, 7
        defb 224, 8
        defb 2, 0
        defb 97, 0
        defb 178, 0
        defb 80, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_a
        defb 7, 240
        defb 15, 192
        defb 42, 128
        defb 85, 0
        defb 42, 0
        defb 84, 0
        defb 32, 128
        defb 62, 128
        defb 63, 128
        defb 31, 192
        defb 15, 192
        defb 17, 128
        defb 42, 0
        defb 21, 128
        defb 2, 192
        defb 1, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 128, 15
        defb 112, 7
        defb 184, 3
        defb 88, 3
        defb 176, 1
        defb 14, 0
        defb 222, 0
        defb 48, 1
        defb 240, 7
        defb 128, 15
        defb 192, 31
        defb 0, 127
        defb 0, 63
        defb 64, 31
        defb 224, 15
        defb 64, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_a
        defb 0, 254
        defb 1, 240
        defb 13, 224
        defb 26, 192
        defb 29, 192
        defb 10, 192
        defb 48, 128
        defb 59, 128
        defb 12, 192
        defb 15, 224
        defb 1, 240
        defb 3, 248
        defb 0, 240
        defb 14, 224
        defb 29, 192
        defb 10, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_b
        defb 224, 15
        defb 240, 7
        defb 240, 3
        defb 168, 1
        defb 84, 0
        defb 170, 0
        defb 84, 0
        defb 4, 1
        defb 124, 1
        defb 252, 1
        defb 248, 3
        defb 240, 7
        defb 64, 15
        defb 160, 7
        defb 80, 3
        defb 168, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_a
        defb 0, 255
        defb 0, 248
        defb 7, 240
        defb 14, 224
        defb 13, 224
        defb 6, 192
        defb 56, 128
        defb 61, 128
        defb 4, 192
        defb 7, 240
        defb 0, 248
        defb 1, 192
        defb 28, 128
        defb 58, 128
        defb 21, 192
        defb 2, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_b
        defb 112, 7
        defb 248, 3
        defb 120, 1
        defb 170, 0
        defb 85, 0
        defb 170, 0
        defb 21, 0
        defb 130, 0
        defb 62, 0
        defb 254, 0
        defb 124, 1
        defb 248, 1
        defb 64, 0
        defb 138, 0
        defb 68, 0
        defb 168, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_a
        defb 1, 252
        defb 3, 224
        defb 29, 192
        defb 58, 128
        defb 53, 128
        defb 26, 0
        defb 224, 0
        defb 246, 0
        defb 24, 0
        defb 31, 192
        defb 1, 224
        defb 7, 16
        defb 64, 0
        defb 134, 0
        defb 77, 0
        defb 10, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_b
        defb 192, 31
        defb 224, 15
        defb 224, 7
        defb 168, 3
        defb 84, 1
        defb 168, 1
        defb 84, 1
        defb 8, 3
        defb 248, 3
        defb 248, 3
        defb 240, 7
        defb 224, 1
        defb 68, 0
        defb 170, 0
        defb 84, 0
        defb 160, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_a
        defb 1, 240
        defb 14, 224
        defb 29, 192
        defb 26, 192
        defb 13, 128
        defb 112, 0
        defb 123, 0
        defb 12, 128
        defb 15, 224
        defb 1, 240
        defb 3, 248
        defb 0, 254
        defb 0, 252
        defb 2, 248
        defb 7, 240
        defb 2, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_b
        defb 224, 15
        defb 240, 3
        defb 84, 1
        defb 170, 0
        defb 84, 0
        defb 42, 0
        defb 4, 1
        defb 124, 1
        defb 252, 1
        defb 248, 3
        defb 240, 3
        defb 136, 1
        defb 84, 0
        defb 168, 1
        defb 64, 3
        defb 128, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_a
        defb 0, 240
        defb 7, 224
        defb 15, 192
        defb 15, 192
        defb 15, 192
        defb 3, 224
        defb 1, 240
        defb 1, 192
        defb 14, 128
        defb 56, 0
        defb 34, 0
        defb 4, 128
        defb 10, 192
        defb 16, 128
        defb 32, 131
        defb 0, 135
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_b
        defb 0, 7
        defb 240, 3
        defb 248, 1
        defb 16, 1
        defb 144, 1
        defb 248, 1
        defb 248, 1
        defb 208, 3
        defb 8, 1
        defb 12, 0
        defb 162, 0
        defb 16, 0
        defb 8, 1
        defb 0, 193
        defb 8, 193
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_a
        defb 0, 255
        defb 0, 240
        defb 7, 224
        defb 15, 192
        defb 15, 192
        defb 15, 192
        defb 3, 224
        defb 1, 224
        defb 13, 128
        defb 56, 0
        defb 34, 0
        defb 5, 128
        defb 0, 240
        defb 0, 248
        defb 1, 248
        defb 0, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_b
        defb 0, 255
        defb 0, 7
        defb 240, 3
        defb 248, 1
        defb 16, 1
        defb 144, 1
        defb 248, 1
        defb 248, 1
        defb 208, 1
        defb 12, 0
        defb 162, 0
        defb 0, 0
        defb 128, 15
        defb 64, 15
        defb 0, 7
        defb 0, 127
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_a
        defb 0, 224
        defb 15, 192
        defb 31, 128
        defb 8, 128
        defb 9, 128
        defb 31, 128
        defb 31, 128
        defb 11, 192
        defb 16, 128
        defb 48, 0
        defb 69, 0
        defb 8, 0
        defb 16, 128
        defb 0, 131
        defb 16, 131
        defb 0, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_b
        defb 0, 15
        defb 224, 7
        defb 240, 3
        defb 240, 3
        defb 240, 3
        defb 192, 7
        defb 128, 15
        defb 128, 3
        defb 112, 1
        defb 28, 0
        defb 68, 0
        defb 32, 1
        defb 80, 3
        defb 8, 1
        defb 4, 193
        defb 0, 225
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_a
        defb 0, 255
        defb 0, 224
        defb 15, 192
        defb 31, 128
        defb 8, 128
        defb 9, 128
        defb 31, 128
        defb 31, 128
        defb 11, 128
        defb 48, 0
        defb 69, 0
        defb 0, 0
        defb 1, 240
        defb 2, 240
        defb 0, 224
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_b
        defb 0, 255
        defb 0, 15
        defb 224, 7
        defb 240, 3
        defb 240, 3
        defb 240, 3
        defb 192, 7
        defb 128, 7
        defb 176, 1
        defb 28, 0
        defb 68, 0
        defb 160, 1
        defb 0, 15
        defb 0, 31
        defb 128, 31
        defb 0, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_a
        defb 0, 255
        defb 0, 254
        defb 0, 252
        defb 1, 248
        defb 0, 248
        defb 1, 240
        defb 0, 240
        defb 5, 224
        defb 10, 192
        defb 4, 192
        defb 8, 192
        defb 4, 192
        defb 8, 192
        defb 16, 0
        defb 32, 0
        defb 0, 4
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_b
        defb 0, 255
        defb 0, 3
        defb 252, 1
        defb 72, 1
        defb 216, 1
        defb 252, 1
        defb 192, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 124, 0
        defb 128, 0
        defb 16, 1
        defb 168, 1
        defb 80, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_a
        defb 0, 255
        defb 0, 240
        defb 3, 224
        defb 6, 192
        defb 10, 192
        defb 23, 128
        defb 14, 128
        defb 23, 0
        defb 47, 0
        defb 87, 0
        defb 35, 0
        defb 17, 0
        defb 34, 0
        defb 16, 0
        defb 32, 0
        defb 0, 6
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_b
        defb 0, 255
        defb 0, 31
        defb 224, 15
        defb 64, 15
        defb 192, 15
        defb 224, 15
        defb 0, 15
        defb 240, 7
        defb 240, 7
        defb 240, 7
        defb 240, 7
        defb 224, 7
        defb 0, 3
        defb 0, 1
        defb 160, 0
        defb 84, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_a
        defb 0, 255
        defb 0, 192
        defb 63, 128
        defb 18, 128
        defb 27, 128
        defb 63, 128
        defb 3, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 62, 0
        defb 1, 0
        defb 8, 128
        defb 21, 128
        defb 10, 128
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_b
        defb 0, 255
        defb 0, 127
        defb 0, 63
        defb 128, 31
        defb 0, 31
        defb 128, 15
        defb 0, 15
        defb 160, 7
        defb 80, 3
        defb 32, 3
        defb 16, 3
        defb 32, 3
        defb 16, 3
        defb 8, 0
        defb 4, 0
        defb 0, 32
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_a
        defb 0, 255
        defb 0, 248
        defb 7, 240
        defb 2, 240
        defb 3, 240
        defb 7, 240
        defb 0, 240
        defb 15, 224
        defb 15, 224
        defb 15, 224
        defb 15, 224
        defb 7, 224
        defb 0, 192
        defb 0, 128
        defb 5, 0
        defb 42, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_b
        defb 0, 255
        defb 0, 15
        defb 192, 7
        defb 96, 3
        defb 80, 3
        defb 232, 1
        defb 112, 1
        defb 232, 0
        defb 244, 0
        defb 234, 0
        defb 196, 0
        defb 136, 0
        defb 68, 0
        defb 8, 0
        defb 4, 0
        defb 0, 96
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_17_a
        defb 0, 224
        defb 15, 192
        defb 31, 128
        defb 0, 128
        defb 63, 0
        defb 39, 0
        defb 11, 128
        defb 21, 128
        defb 10, 192
        defb 13, 192
        defb 31, 128
        defb 31, 128
        defb 0, 192
        defb 8, 129
        defb 16, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_17_b
        defb 0, 31
        defb 192, 15
        defb 0, 7
        defb 240, 3
        defb 168, 3
        defb 168, 3
        defb 168, 3
        defb 168, 3
        defb 240, 3
        defb 64, 7
        defb 128, 15
        defb 224, 7
        defb 0, 3
        defb 8, 129
        defb 16, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_17_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_18_a
        defb 0, 255
        defb 0, 224
        defb 15, 192
        defb 31, 128
        defb 0, 128
        defb 63, 0
        defb 39, 0
        defb 11, 128
        defb 21, 128
        defb 10, 192
        defb 13, 192
        defb 31, 128
        defb 5, 128
        defb 24, 128
        defb 0, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_18_b
        defb 0, 255
        defb 0, 31
        defb 192, 15
        defb 0, 7
        defb 240, 3
        defb 168, 3
        defb 168, 3
        defb 168, 3
        defb 168, 3
        defb 240, 3
        defb 64, 7
        defb 128, 15
        defb 64, 3
        defb 0, 1
        defb 24, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_18_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_19_a
        defb 0, 248
        defb 3, 240
        defb 0, 224
        defb 15, 192
        defb 21, 192
        defb 21, 192
        defb 21, 192
        defb 21, 192
        defb 15, 192
        defb 2, 224
        defb 1, 240
        defb 7, 224
        defb 0, 192
        defb 16, 129
        defb 8, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_19_b
        defb 0, 7
        defb 240, 3
        defb 248, 1
        defb 0, 1
        defb 252, 0
        defb 228, 0
        defb 208, 1
        defb 168, 1
        defb 80, 3
        defb 176, 3
        defb 248, 1
        defb 248, 1
        defb 0, 3
        defb 16, 129
        defb 8, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_19_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_20_a
        defb 0, 255
        defb 0, 248
        defb 3, 240
        defb 0, 224
        defb 15, 192
        defb 21, 192
        defb 21, 192
        defb 21, 192
        defb 21, 192
        defb 15, 192
        defb 2, 224
        defb 1, 240
        defb 2, 192
        defb 0, 128
        defb 24, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_20_b
        defb 0, 255
        defb 0, 7
        defb 240, 3
        defb 248, 1
        defb 0, 1
        defb 252, 0
        defb 228, 0
        defb 208, 1
        defb 168, 1
        defb 80, 3
        defb 176, 3
        defb 248, 1
        defb 160, 1
        defb 24, 1
        defb 0, 129
        defb 0, 195
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_20_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_21_a
        defb 0, 255
        defb 0, 255
        defb 0, 254
        defb 1, 252
        defb 1, 240
        defb 6, 128
        defb 43, 0
        defb 80, 0
        defb 0, 1
        defb 80, 1
        defb 36, 0
        defb 14, 128
        defb 3, 224
        defb 0, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_21_b
        defb 0, 255
        defb 0, 39
        defb 144, 7
        defb 176, 7
        defb 176, 7
        defb 64, 3
        defb 248, 1
        defb 248, 1
        defb 0, 3
        defb 0, 255
        defb 0, 255
        defb 0, 63
        defb 128, 31
        defb 0, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_21_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_22_a
        defb 0, 255
        defb 0, 255
        defb 0, 252
        defb 1, 248
        defb 2, 240
        defb 0, 240
        defb 2, 224
        defb 0, 224
        defb 2, 224
        defb 4, 224
        defb 2, 224
        defb 0, 224
        defb 6, 224
        defb 3, 240
        defb 0, 248
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_22_b
        defb 36, 129
        defb 108, 1
        defb 108, 1
        defb 144, 0
        defb 254, 0
        defb 62, 0
        defb 0, 0
        defb 0, 127
        defb 0, 127
        defb 0, 127
        defb 0, 127
        defb 0, 127
        defb 0, 127
        defb 0, 31
        defb 192, 15
        defb 0, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_22_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_23_a
        defb 0, 255
        defb 0, 228
        defb 9, 224
        defb 13, 224
        defb 13, 224
        defb 2, 192
        defb 31, 128
        defb 31, 128
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 252
        defb 1, 248
        defb 0, 252
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_23_b
        defb 0, 255
        defb 0, 255
        defb 0, 127
        defb 128, 63
        defb 128, 15
        defb 96, 1
        defb 212, 0
        defb 10, 0
        defb 0, 128
        defb 10, 128
        defb 36, 0
        defb 112, 1
        defb 192, 7
        defb 0, 31
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_23_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_24_a
        defb 36, 129
        defb 54, 128
        defb 54, 128
        defb 9, 0
        defb 127, 0
        defb 124, 0
        defb 0, 0
        defb 0, 254
        defb 0, 254
        defb 0, 254
        defb 0, 254
        defb 0, 254
        defb 0, 254
        defb 0, 248
        defb 3, 240
        defb 0, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_24_b
        defb 0, 255
        defb 0, 255
        defb 0, 63
        defb 128, 31
        defb 64, 15
        defb 0, 15
        defb 64, 7
        defb 0, 7
        defb 64, 7
        defb 32, 7
        defb 64, 7
        defb 0, 7
        defb 96, 7
        defb 192, 15
        defb 0, 31
        defb 0, 127
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_24_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
#endasm
 
